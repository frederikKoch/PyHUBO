class VariableAssignment():
    pass