class VariableDictionary:
    pass