class HuboHamiltonian:
    pass

class PauliZ:
    pass