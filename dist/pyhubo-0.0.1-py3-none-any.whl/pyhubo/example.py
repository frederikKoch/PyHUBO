def add_one(number):
    return number + 1

"""
To be filled soon
"""